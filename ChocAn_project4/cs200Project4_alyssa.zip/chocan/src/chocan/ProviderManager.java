package chocan;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Manages ChocAn provider records.
 *
 * Author: Alyssa Duncan
 */
public class ProviderManager {

    private final DataStore data;
    private final Scanner input;
    private final ArrayList<Provider> providers;

    public ProviderManager(DataStore data, Scanner input) {
        this.data = data;
        this.input = input;
        this.providers = new ArrayList<>();
    }

    /**
     * Adds a new provider.
     */
    public void addProvider() {
        System.out.println("\n--- Add Provider ---");

        System.out.print("Enter provider number (9 digits): ");
        String number = input.nextLine().trim();

        if (findProvider(number) != null) {
            System.out.println("A provider with that number already exists.");
            return;
        }

        System.out.print("Enter provider name: ");
        String name = input.nextLine().trim();

        System.out.print("Enter street address: ");
        String address = input.nextLine().trim();

        System.out.print("Enter city: ");
        String city = input.nextLine().trim();

        System.out.print("Enter state: ");
        String state = input.nextLine().trim();

        System.out.print("Enter ZIP code: ");
        String zip = input.nextLine().trim();

        System.out.print("Enter provider type: ");
        String type = input.nextLine().trim();

        System.out.print("Enter email: ");
        String email = input.nextLine().trim();

        Provider provider = new Provider(
            number,
            name,
            address,
            city,
            state,
            zip,
            type,
            email
        );

        providers.add(provider);

        System.out.println("Provider added successfully.");
    }

    /**
     * Finds a provider using the provider number.
     */
    public Provider findProvider(String providerNumber) {
        for (Provider provider : providers) {
            if (provider.getProviderNumber().equals(providerNumber)) {
                return provider;
            }
        }

        return null;
    }

    /**
     * Edits an existing provider.
     */
    public void editProvider() {
        System.out.println("\n--- Edit Provider ---");

        System.out.print("Enter provider number: ");
        String number = input.nextLine().trim();

        Provider provider = findProvider(number);

        if (provider == null) {
            System.out.println("Provider not found.");
            return;
        }

        System.out.println("Press ENTER to keep the current value.");

        System.out.print("Name [" + provider.getName() + "]: ");
        String value = input.nextLine().trim();
        if (!value.isEmpty()) {
            provider.setName(value);
        }

        System.out.print(
            "Street address [" +
            provider.getStreetAddress() + "]: "
        );
        value = input.nextLine().trim();
        if (!value.isEmpty()) {
            provider.setStreetAddress(value);
        }

        System.out.print("City [" + provider.getCity() + "]: ");
        value = input.nextLine().trim();
        if (!value.isEmpty()) {
            provider.setCity(value);
        }

        System.out.print("State [" + provider.getState() + "]: ");
        value = input.nextLine().trim();
        if (!value.isEmpty()) {
            provider.setState(value);
        }

        System.out.print("ZIP code [" + provider.getZipCode() + "]: ");
        value = input.nextLine().trim();
        if (!value.isEmpty()) {
            provider.setZipCode(value);
        }

        System.out.print(
            "Provider type [" +
            provider.getProviderType() + "]: "
        );
        value = input.nextLine().trim();
        if (!value.isEmpty()) {
            provider.setProviderType(value);
        }

        System.out.print("Email [" + provider.getEmail() + "]: ");
        value = input.nextLine().trim();
        if (!value.isEmpty()) {
            provider.setEmail(value);
        }

        System.out.println("Provider updated successfully.");
    }

    /**
     * Deletes an existing provider.
     */
    public void deleteProvider() {
        System.out.println("\n--- Delete Provider ---");

        System.out.print("Enter provider number: ");
        String number = input.nextLine().trim();

        Provider provider = findProvider(number);

        if (provider == null) {
            System.out.println("Provider not found.");
            return;
        }

        System.out.print(
            "Are you sure you want to delete " +
            provider.getName() + "? (Y/N): "
        );

        String confirmation = input.nextLine().trim();

        if (confirmation.equalsIgnoreCase("Y")) {
            providers.remove(provider);
            System.out.println("Provider deleted successfully.");
        } else {
            System.out.println("Delete cancelled.");
        }
    }

    /**
     * Lists all providers.
     */
    public void listProviders() {
        System.out.println("\n--- Provider List ---");

        if (providers.isEmpty()) {
            System.out.println("No providers found.");
            return;
        }

        for (Provider provider : providers) {
            System.out.println("------------------------------");
            System.out.println(provider);
        }
    }

    /**
     * Returns the provider collection.
     */
    public ArrayList<Provider> getProviders() {
        return providers;
    }
}