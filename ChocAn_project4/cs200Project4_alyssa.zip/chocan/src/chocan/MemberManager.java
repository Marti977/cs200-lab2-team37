package chocan;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Manages ChocAn member records.
 *
 * Author: Alyssa Duncan
 */
public class MemberManager {

    private final DataStore data;
    private final Scanner input;

    /*
     * This list is kept by the manager as the working collection of members.
     * The DataStore object is also retained so the manager can be integrated
     * with the project's shared data storage.
     */
    private final ArrayList<Member> members;

    public MemberManager(DataStore data, Scanner input) {
        this.data = data;
        this.input = input;
        this.members = new ArrayList<>();
    }

    /**
     * Adds a new member.
     */
    public void addMember() {
        System.out.println("\n--- Add Member ---");

        System.out.print("Enter member number (9 digits): ");
        String number = input.nextLine().trim();

        if (findMember(number) != null) {
            System.out.println("A member with that number already exists.");
            return;
        }

        System.out.print("Enter member name: ");
        String name = input.nextLine().trim();

        System.out.print("Enter street address: ");
        String address = input.nextLine().trim();

        System.out.print("Enter city: ");
        String city = input.nextLine().trim();

        System.out.print("Enter state: ");
        String state = input.nextLine().trim();

        System.out.print("Enter ZIP code: ");
        String zip = input.nextLine().trim();

        Member member = new Member(
            number,
            name,
            address,
            city,
            state,
            zip,
            "active"
        );

        members.add(member);

        System.out.println("Member added successfully.");
    }

    /**
     * Finds a member using the member number.
     */
    public Member findMember(String memberNumber) {
        for (Member member : members) {
            if (member.getMemberNumber().equals(memberNumber)) {
                return member;
            }
        }

        return null;
    }

    /**
     * Edits an existing member.
     */
    public void editMember() {
        System.out.println("\n--- Edit Member ---");

        System.out.print("Enter member number: ");
        String number = input.nextLine().trim();

        Member member = findMember(number);

        if (member == null) {
            System.out.println("Member not found.");
            return;
        }

        System.out.println("Press ENTER to keep the current value.");

        System.out.print("Name [" + member.getName() + "]: ");
        String value = input.nextLine().trim();
        if (!value.isEmpty()) {
            member.setName(value);
        }

        System.out.print("Street address [" + member.getStreetAddress() + "]: ");
        value = input.nextLine().trim();
        if (!value.isEmpty()) {
            member.setStreetAddress(value);
        }

        System.out.print("City [" + member.getCity() + "]: ");
        value = input.nextLine().trim();
        if (!value.isEmpty()) {
            member.setCity(value);
        }

        System.out.print("State [" + member.getState() + "]: ");
        value = input.nextLine().trim();
        if (!value.isEmpty()) {
            member.setState(value);
        }

        System.out.print("ZIP code [" + member.getZipCode() + "]: ");
        value = input.nextLine().trim();
        if (!value.isEmpty()) {
            member.setZipCode(value);
        }

        System.out.print("Status [" + member.getStatus() + "]: ");
        value = input.nextLine().trim();

        if (!value.isEmpty()) {
            try {
                member.setStatus(value);
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid status. Status must be active or suspended.");
            }
        }

        System.out.println("Member updated successfully.");
    }

    /**
     * Deletes an existing member.
     */
    public void deleteMember() {
        System.out.println("\n--- Delete Member ---");

        System.out.print("Enter member number: ");
        String number = input.nextLine().trim();

        Member member = findMember(number);

        if (member == null) {
            System.out.println("Member not found.");
            return;
        }

        System.out.print(
            "Are you sure you want to delete " +
            member.getName() + "? (Y/N): "
        );

        String confirmation = input.nextLine().trim();

        if (confirmation.equalsIgnoreCase("Y")) {
            members.remove(member);
            System.out.println("Member deleted successfully.");
        } else {
            System.out.println("Delete cancelled.");
        }
    }

    /**
     * Lists all members.
     */
    public void listMembers() {
        System.out.println("\n--- Member List ---");

        if (members.isEmpty()) {
            System.out.println("No members found.");
            return;
        }

        for (Member member : members) {
            System.out.println("------------------------------");
            System.out.println(member);
        }
    }

    /**
     * Applies membership status updates received from Acme.
     *
     * This is included because Main.java and Operator.java both call it.
     */
    public void applyAcmeMembershipUpdates() {
        System.out.println("\n--- Acme Membership Updates ---");

        if (members.isEmpty()) {
            System.out.println("No members available for updates.");
            return;
        }

        System.out.print("Enter member number to update: ");
        String number = input.nextLine().trim();

        Member member = findMember(number);

        if (member == null) {
            System.out.println("Member not found.");
            return;
        }

        System.out.println("Current status: " + member.getStatus());
        System.out.print("Enter new status (active/suspended): ");

        String status = input.nextLine().trim();

        try {
            member.setStatus(status);
            System.out.println("Membership status updated successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid status.");
        }
    }

    /**
     * Returns the member collection.
     */
    public ArrayList<Member> getMembers() {
        return members;
    }
}