// Author: [Team member name]
package chocan;

import java.util.Scanner;
import java.time.LocalDateTime;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Starts ChocAn, authenticates users, and opens the correct role menu. */
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        DataStore data = new DataStore();

        Login login = new Login(input);
        MemberManager members = new MemberManager(data, input);
        ProviderManager providers = new ProviderManager(data, input);
        ServiceManager services = new ServiceManager(data, input);

        ReportGenerator reports = new ReportGenerator(data);
        Accounting accounting = new Accounting(data, reports);
        ProviderDirectory directory = new ProviderDirectory(services);

        System.out.println("====================================");
        System.out.println(" CHOCOHOLICS ANONYMOUS (ChocAn)");
        System.out.println("====================================");
        System.out.println("Demo login: operator/op123 | provider/pr123 | manager/mg123");

        ScheduledExecutorService timer =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "ChocAn-Scheduler");
                t.setDaemon(true);
                return t;
            });

        final String[] lastNightly = {""};
        final String[] lastWeekly = {""};

        timer.scheduleAtFixedRate(() -> {
            LocalDateTime now = LocalDateTime.now();
            String day = now.toLocalDate().toString();

            if (now.getHour() == 21 && now.getMinute() == 0
                    && !day.equals(lastNightly[0])) {
                members.applyAcmeMembershipUpdates();
                lastNightly[0] = day;
            }

            String weekKey = now.toLocalDate().toString();

            if (now.getDayOfWeek() == java.time.DayOfWeek.SATURDAY
                    && now.getHour() == 0 && now.getMinute() == 0
                    && !weekKey.equals(lastWeekly[0])) {
                accounting.runAccountingProcedure();
                lastWeekly[0] = weekKey;
            }
        }, 0, 30, TimeUnit.SECONDS);

        boolean running = true;

        while (running) {
            User user = login.authenticate();

            if (user == null) {
                continue;
            }

            if (user.username().equals("__EXIT__")) {
                break;
            }

            switch (user.role()) {
                case OPERATOR ->
                    new Operator(input, members, providers, services).displayMenu();

                case PROVIDER ->
                    new ProviderUser(input, services, data, user).displayMenu();

                case MANAGER ->
                    new Manager(input, accounting, reports, directory).displayMenu();
            }
        }

        timer.shutdownNow();
        data.save();

        System.out.println("ChocAn closed. Saved records remain available next time.");
    }
}
